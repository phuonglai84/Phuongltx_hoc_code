def anagram_number(number):
    pass

def roman_to_int(s):
    pass