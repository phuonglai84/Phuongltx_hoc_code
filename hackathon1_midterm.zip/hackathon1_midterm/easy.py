# 1
def day_diff(release_date, code_complete_day):
    pass

# 2
def alpha_num(sentence):
    pass