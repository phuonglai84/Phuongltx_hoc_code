import sys
from db import get_movies, get_actors, find_movie


def print_all_movies():
    pass


def print_all_actors():
    pass


def print_movie_info():
    pass


def quit():
    print("Have fun")
    sys.exit()
